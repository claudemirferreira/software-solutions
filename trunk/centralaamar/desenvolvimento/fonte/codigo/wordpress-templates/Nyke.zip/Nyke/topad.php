<div class="topbanner">
<?php $ad2 = get_option('nyke_ad2'); echo stripslashes($ad2); ?>
</div>
<div class="clear"></div>