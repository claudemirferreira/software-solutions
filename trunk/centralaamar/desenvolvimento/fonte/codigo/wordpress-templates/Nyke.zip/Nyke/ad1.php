<div class="widebanner">
<?php $ad1 = get_option('nyke_ad1'); echo stripslashes($ad1); ?>
</div>
<div class="clear"></div>