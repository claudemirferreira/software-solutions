Top Blog Formula eDegree��Theme

This theme is designed to help your site rank higher in search engines and increase your blog readers. You will also be able to change the color scheme of your site and adopt your own design through your custom header, background images and etc. Enjoy =)

Support and updates available at www.topblogformula.com

INSTALLATION STEPS:

1. Login to your WordPress dashboard.

2. Use the WordPress' "Add New Themes" option to upload the zipped folder (v2.8+) or upload the theme folder via FTP to your wp-content/themes/ directory.

3. Activate intrepid theme under "Appearance"

4. [Optional] Download the latest version of the Featured Content Gallery plugin (http://wordpress.org/extend/plugins/featured-content-gallery/)

5. [Optional] Upload the Featured Content Gallery plugin via FTP to your wp-content/plugins directory, activate it, and follow the directions from the plugin page.

6. Inside your WordPress dashboard, go to "My Theme" towards the bottom and configure your site such as logo, facebook link, homepage contents, navigation, and etc.


Shingo Suzumura

shingo.suzumura@gmail.com

http://www.sz-solutions.com/blog/contact