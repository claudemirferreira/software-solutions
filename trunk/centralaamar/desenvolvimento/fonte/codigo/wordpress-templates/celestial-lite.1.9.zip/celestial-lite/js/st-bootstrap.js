// lets add some bootstrap styling to WordPress elements

jQuery(function($){
	$( 'table' ).addClass( 'table' );
	$( '#submit' ).addClass( 'btn btn-primary btn-small' );
	$( '#wp-calendar' ).addClass( 'table table-striped table-bordered' );
	
});