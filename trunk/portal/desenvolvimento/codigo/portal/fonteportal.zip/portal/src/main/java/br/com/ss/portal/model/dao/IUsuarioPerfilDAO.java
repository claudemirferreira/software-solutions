package br.com.ss.portal.model.dao;

import br.com.ss.portal.model.entity.UsuarioPerfil;

public interface IUsuarioPerfilDAO extends IAbstractDAO<UsuarioPerfil> {

}