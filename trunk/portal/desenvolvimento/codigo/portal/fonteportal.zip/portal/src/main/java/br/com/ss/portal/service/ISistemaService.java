package br.com.ss.portal.service;

import br.com.ss.portal.model.entity.Sistema;

public interface ISistemaService extends IService<Sistema> {

}