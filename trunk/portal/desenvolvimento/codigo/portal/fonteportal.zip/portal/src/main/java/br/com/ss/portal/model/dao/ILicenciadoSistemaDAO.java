package br.com.ss.portal.model.dao;

import br.com.ss.portal.model.entity.LicenciadoSistema;

public interface ILicenciadoSistemaDAO extends IAbstractDAO<LicenciadoSistema> {

}