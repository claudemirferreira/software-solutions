package br.com.ss.portal.service;

import br.com.ss.portal.model.entity.Licenciado;

public interface ILicenciadoService extends IService<Licenciado> {

}