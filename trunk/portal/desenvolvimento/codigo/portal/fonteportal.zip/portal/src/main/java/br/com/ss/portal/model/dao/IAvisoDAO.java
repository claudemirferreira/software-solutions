package br.com.ss.portal.model.dao;

import br.com.ss.portal.model.entity.Aviso;

public interface IAvisoDAO extends IAbstractDAO<Aviso> {

}