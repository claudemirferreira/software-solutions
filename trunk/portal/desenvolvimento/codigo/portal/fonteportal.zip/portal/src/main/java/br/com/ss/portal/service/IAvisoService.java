package br.com.ss.portal.service;

import br.com.ss.portal.model.entity.Aviso;

public interface IAvisoService extends IService<Aviso> {

}