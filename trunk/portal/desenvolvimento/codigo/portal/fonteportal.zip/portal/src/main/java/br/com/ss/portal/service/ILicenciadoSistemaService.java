package br.com.ss.portal.service;

import br.com.ss.portal.model.entity.LicenciadoSistema;

public interface ILicenciadoSistemaService extends IService<LicenciadoSistema> {

}