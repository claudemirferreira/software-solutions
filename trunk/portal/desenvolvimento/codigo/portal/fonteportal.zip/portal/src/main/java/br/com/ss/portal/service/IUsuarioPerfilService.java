package br.com.ss.portal.service;

import br.com.ss.portal.model.entity.UsuarioPerfil;

public interface IUsuarioPerfilService extends IService<UsuarioPerfil> {

}