package br.com.ss.portal.model.dao;

import br.com.ss.portal.model.entity.Sistema;

public interface ISistemaDAO extends IAbstractDAO<Sistema> {

}