package br.com.ss.portal.util;

public class Teste {
	public static void main(String[] args) {
		System.out.println("1 = "+Math.sqrt(1));
		System.out.println("2 = "+Math.sqrt(2));
		System.out.println("3 = "+Math.sqrt(3));
		System.out.println("4 = "+Math.sqrt(4));
		System.out.println("5 = "+Math.sqrt(5));
		System.out.println("6 = "+Math.sqrt(6));
		System.out.println("7 = "+Math.sqrt(7));
		System.out.println("8 = "+Math.sqrt(8));
		System.out.println("9 = "+Math.sqrt(9));
		System.out.println("10 = "+Math.sqrt(10));
		System.out.println("11 = "+Math.sqrt(11));
		System.out.println("12 = "+Math.sqrt(12));
		System.out.println("13 = "+Math.sqrt(13));
		System.out.println("14 = "+Math.sqrt(14));
		System.out.println("15 = "+Math.sqrt(15));
		System.out.println("16 = "+Math.sqrt(16));
		System.out.println("17 = "+Math.sqrt(17));
		System.out.println("18 = "+Math.sqrt(18));
		System.out.println("19 = "+Math.sqrt(19));
		System.out.println("20 = "+Math.sqrt(20));
		System.out.println("21 = "+Math.sqrt(21));
		System.out.println("22 = "+Math.sqrt(22));
		System.out.println("23 = "+Math.sqrt(23));
		System.out.println("24 = "+Math.sqrt(24));
		System.out.println("25 = "+Math.sqrt(24));
	}

}
