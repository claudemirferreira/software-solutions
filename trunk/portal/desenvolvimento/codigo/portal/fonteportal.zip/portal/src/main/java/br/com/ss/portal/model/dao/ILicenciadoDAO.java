package br.com.ss.portal.model.dao;

import br.com.ss.portal.model.entity.Licenciado;

public interface ILicenciadoDAO extends IAbstractDAO<Licenciado> {

}