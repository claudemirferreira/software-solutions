package br.com.ss.portal.util;

public class Util {

	public static int definirTamanhoColuna(int numero) {
		return (int) Math.sqrt(numero) + 1;
	}
}
