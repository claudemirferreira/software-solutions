<?php get_header(); ?>

<div class="body">
<div class="blog">

   <h2 class="search">Error 404 : No Page Found!</h2>

</div><!--blog-->

<?php get_sidebar(); ?>

</div><!--body-->

</div><!--wrapper-->

<?php get_footer(); ?>

</body>
</html>