<?php get_header(); ?>

	<div class="page">

		<h2><?php _e('We\'re sorry - that page was not found (Error 404)')?></h2>
        <p><?php _e('Make sure the URL is correct. Try searching for it.')?></p>
        <?php include('searchform.php') ?>

	</div>

<?php get_footer(); ?>