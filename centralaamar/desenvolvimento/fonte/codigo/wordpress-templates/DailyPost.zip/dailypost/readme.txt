DailyPost is a intresting theme ideal for your everyday notes and thoughts, which supports post formats and several customisation options. The theme is a special one because of it's responsive design, thus you will get the pleasure to read the post with your mobile device.

Theme Features:
Responsible Web Design
Post Format
Custom Widgets
Internationalized & localization
SEO Options Section
Full HTML5 and CSS3
Frequent theme upgrades
Wordpress APIs respected
Clean Code
Microformats
Cross-browser compatibility
Threaded Comments
Gravatar ready

Follow Theme Updates at http://wplook.com/DailyPost